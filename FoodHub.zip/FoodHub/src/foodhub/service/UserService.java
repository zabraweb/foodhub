package foodhub.service;
import foodhub.dao.impl.UserDaoImpl;
import foodhub.model.Contact;

import foodhub.model.User;
import foodhub.model.UserUpdate;

public class UserService {
	UserDaoImpl dao;
	public UserService(){
		dao=new UserDaoImpl();
	}
	
	public boolean addUser(User u){
		return dao.addUser(u);
		
	}
	
	public boolean addContact(Contact c){
		return dao.addContact(c);
	}
	public boolean delete(String first_name){
		return true;
		
	}
	public boolean update(UserUpdate up){
		return dao.update(up);
		
	}

}

