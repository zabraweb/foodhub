package foodhub;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import foodhub.model.LoginModel;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init(ServletConfig config) throws ServletException {
		
	}
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter();
		
		String email=request.getParameter("email");
		String pass=request.getParameter("pass");
		if(LoginModel.validate(email, pass)){
			HttpSession session=request.getSession();
			session.setAttribute("email", email);
			
			/*if(LoginModel.role.equals("Admin"))
			{
			
			session.setAttribute("email", email);
			request.getRequestDispatcher("admin.jsp").include(request, response);
			}
			else
			{*/
			
			RequestDispatcher rd=request.getRequestDispatcher("welcome.jsp");
			rd.forward(request, response);
			
			//}
		}
		else {
			request.setAttribute("message", "Username and password is incorrrect");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		
		
		
	}
	

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String action=req.getParameter("action");
		if(action==null)
			req.getRequestDispatcher("login.jsp").forward(req, resp);
		else if(action.equalsIgnoreCase("logout")){
			HttpSession session=req.getSession();
			session.invalidate();
			req.getRequestDispatcher("login.jsp").forward(req, resp);
		}
		
	}
	
	

}
