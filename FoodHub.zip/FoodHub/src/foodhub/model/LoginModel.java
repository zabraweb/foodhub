package foodhub.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginModel {
	public static String role;
	public static boolean validate(String email, String pass){
		boolean status =false;
		
		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
			PreparedStatement pstmt=con.prepareStatement("Select * from userdetails where email=? and password=?");
			pstmt.setString(1, email);
			pstmt.setString(2, pass);
			ResultSet rs=pstmt.executeQuery();
			status=rs.next();
			 role=(String)rs.getString("ROLE");
			
		}catch(Exception e){
			System.out.println(e);
			
		}
		return status;
	}
	

	

}
