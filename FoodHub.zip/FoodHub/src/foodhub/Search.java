package foodhub;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/search")
public class Search extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		response.getWriter();
		Connection conn = null;
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String username = "hr";
		String password = "hr";

		PreparedStatement st;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, username, password);
			System.out.println("Connected!");
			String uname = request.getParameter("username");

			ArrayList<String> al = null;
			ArrayList<ArrayList<String>> uname_list = new ArrayList<ArrayList<String>>();
			String query = "select * from userdetails where First_Name='" + uname + "'";
			st = (PreparedStatement) conn.prepareStatement(query);
			ResultSet rs = st.executeQuery(query);
			while (rs.next()) {
				al = new ArrayList<String>();

				//
				
				al.add(rs.getString(1));
				al.add(rs.getString(2));
				al.add(rs.getString(3));
				al.add(rs.getString(4));
				uname_list.add(al);
			}

			request.setAttribute("unamet", uname_list);
			RequestDispatcher view = request.getRequestDispatcher("searchview.jsp");
			view.forward(request, response);
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	@Override
	public String getServletInfo() {
		return "Short description";
	}
}