package foodhub.dao;

import foodhub.model.Contact;

import foodhub.model.User;
import foodhub.model.UserUpdate;

public interface UserDao {
	public boolean addUser(User u);
	
	public boolean addContact(Contact c);
	public boolean delete(String first_name);
	public boolean update(UserUpdate up);
		
	
	
	


}

