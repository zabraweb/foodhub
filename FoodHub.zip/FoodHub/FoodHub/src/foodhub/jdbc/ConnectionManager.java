package foodhub.jdbc;
import java.sql.*;

public class ConnectionManager{
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String username="hr";
		String password="hr";
		Connection con;		
		public Connection makeConn(){			
			try{
				//step1:Load the driver class
				Class.forName("oracle.jdbc.driver.OracleDriver");
				//step2:get the connection
				con=DriverManager.getConnection(url,username,password);			
				
			}catch(ClassNotFoundException clfne){
				clfne.printStackTrace();
			}
			catch(SQLException sqle){
				sqle.printStackTrace();
			}			
			return con;			
		}
		/*public static void  main(String... a){
			System.out.println(new ConnectionManager().makeConn());
		}*/

}