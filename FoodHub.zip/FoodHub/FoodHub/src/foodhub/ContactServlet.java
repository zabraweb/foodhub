package foodhub;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import foodhub.model.Contact;
import foodhub.service.UserService;

@WebServlet("/contact")
public class ContactServlet extends HttpServlet {
	

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String username=req.getParameter("username");
		String email=req.getParameter("email");
		String subject=req.getParameter("subject");
		String phone=req.getParameter("phone");
		String message=req.getParameter("message");
		//call user service
		req.getRequestDispatcher("contactus.jsp").include(req, res);
		UserService uservice=new UserService();
		//create a user
		Contact c=new Contact();
		c.setName(username);
		c.setEmail(email);
		c.setSubject(subject);
		c.setPhone(phone);
		c.setMessage(message);
		uservice.addContact(c);
		
	}

}
