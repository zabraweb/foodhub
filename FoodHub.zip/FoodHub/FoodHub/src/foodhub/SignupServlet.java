package foodhub;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import foodhub.model.User;
import foodhub.service.UserService;

@WebServlet("/signup")

public class SignupServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{
			PrintWriter out=res.getWriter();
			String fname=req.getParameter("fname");
			String lname=req.getParameter("lname");
			String email=req.getParameter("email");
			String pass=req.getParameter("pass");
			//call user service
			out.print("<p style=\"color:red\">Your registrstion successfully!</p>");
			req.getRequestDispatcher("welcome.jsp").include(req, res);
			UserService uservice=new UserService();
			//create a user
			User u=new User();
			u.setFname(fname);
			u.setLname(lname);
			u.setEmail(email);
			u.setPass(pass);
			uservice.addUser(u);
			
			
	}

}
