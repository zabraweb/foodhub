package foodhub.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import foodhub.dao.UserDao;
import foodhub.jdbc.ConnectionManager;
import foodhub.model.Contact;

import foodhub.model.User;

public  class UserDaoImpl implements UserDao{
	
	Connection con;
	PreparedStatement pstmt;
	int rowsAffected;
	boolean insertStatus,readStatus;
	
	public UserDaoImpl(){
		con=new ConnectionManager().makeConn();
	}
	public boolean addUser(User u) {
		//C:CREATE :insert
		try{
			String query="insert into UserDetails values(?,?,?,?)";
			pstmt=con.prepareStatement(query);
			pstmt.setString(1,u.getFname());
			pstmt.setString(2,u.getLname());	
			pstmt.setString(3,u.getEmail());
			pstmt.setString(4,u.getPass());
			rowsAffected=pstmt.executeUpdate();			
		}
		catch(SQLException sqle){
			sqle.printStackTrace();
		}
		if(rowsAffected >0)
			insertStatus=true;
	
		return insertStatus;	
		
		
	}
	
	public boolean addContact(Contact c) {
		//C:CREATE :insert
		try{
			String query="insert into Contact values(?,?,?,?,?)";
			pstmt=con.prepareStatement(query);
			pstmt.setString(1,c.getName());
			pstmt.setString(2,c.getEmail());	
			pstmt.setString(3,c.getSubject());
			pstmt.setString(4,c.getPhone());
			pstmt.setString(5,c.getMessage());
			rowsAffected=pstmt.executeUpdate();			
		}
		catch(SQLException sqle){
			sqle.printStackTrace();
		}
		if(rowsAffected >0)
			insertStatus=true;
	
		return insertStatus;	
			
		}
		
	}
	
	
	

