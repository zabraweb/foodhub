package foodhub.dao;

import foodhub.model.Contact;

import foodhub.model.User;

public interface UserDao {
	public boolean addUser(User u);
	
	public boolean addContact(Contact c);
	
	


}

