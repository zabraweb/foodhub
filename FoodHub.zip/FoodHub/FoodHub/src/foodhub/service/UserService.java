package foodhub.service;
import foodhub.dao.impl.UserDaoImpl;
import foodhub.model.Contact;

import foodhub.model.User;

public class UserService {
	UserDaoImpl dao;
	public UserService(){
		dao=new UserDaoImpl();
	}
	
	public boolean addUser(User u){
		return dao.addUser(u);
		
	}
	
	public boolean addContact(Contact c){
		return dao.addContact(c);
	}

}

